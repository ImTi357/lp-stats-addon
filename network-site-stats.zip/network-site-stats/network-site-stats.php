<?php
/**
 * Plugin Name: Network Site Stats
 * Description: Plugin quản lý tập trung hiển thị thống kê (số bài viết, ngày cập nhật) của các site con trong mạng lưới.
 * Version: 1.0.0
 * Author: Thang
 * Network: true
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// 1. Thêm Menu vào Network Admin Dashboard
add_action('network_admin_menu', 'nss_add_network_menu');
function nss_add_network_menu() {
    add_menu_page(
        'Thống kê Mạng lưới',     // Tiêu đề trang
        'Site Stats',             // Tên menu
        'manage_network',         // Quyền hạn (chỉ Super Admin)
        'network-site-stats',     // Slug
        'nss_render_admin_page',  // Hàm hiển thị giao diện
        'dashicons-chart-bar',    // Icon
        3                         // Vị trí
    );
}

// 2. Hàm hiển thị giao diện và lấy dữ liệu
function nss_render_admin_page() {
    // Kiểm tra quyền
    if ( ! current_user_can( 'manage_network' ) ) {
        wp_die( 'Bạn không có quyền truy cập trang này.' );
    }

    echo '<div class="wrap">';
    echo '<h1>Thống kê Mạng lưới Website (Network Site Stats)</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead>
            <tr>
                <th>ID</th>
                <th>Tên Site (Blog Name)</th>
                <th>Đường dẫn</th>
                <th>Số lượng bài viết</th>
                <th>Bài đăng mới nhất</th>
            </tr>
          </thead>';
    echo '<tbody>';

    // Lấy danh sách tất cả các trang web trong mạng lưới
    $sites = get_sites();

    if ( $sites ) {
        foreach ( $sites as $site ) {
            $blog_id = $site->blog_id;

            // Chuyển đổi ngữ cảnh sang site con
            switch_to_blog( $blog_id );

            // Lấy dữ liệu của site con hiện tại
            $blog_name = get_bloginfo( 'name' );
            $blog_url = get_home_url();
            
            // Đếm số lượng bài viết đã xuất bản
            $post_count = wp_count_posts( 'post' )->publish;

            // Lấy ngày đăng bài mới nhất
            $latest_post = get_posts( array(
                'posts_per_page' => 1,
                'post_status'    => 'publish',
                'orderby'        => 'date',
                'order'          => 'DESC'
            ) );
            
            $last_updated = 'Chưa có bài viết';
            if ( ! empty( $latest_post ) ) {
                $last_updated = date_i18n( get_option('date_format'), strtotime($latest_post[0]->post_date) );
            }

            // Trả lại ngữ cảnh về site gốc (Quan trọng!)
            restore_current_blog();

            // In dữ liệu ra bảng
            echo '<tr>';
            echo '<td>' . esc_html( $blog_id ) . '</td>';
            echo '<td><strong>' . esc_html( $blog_name ) . '</strong></td>';
            echo '<td><a href="' . esc_url( $blog_url ) . '" target="_blank">' . esc_html( $blog_url ) . '</a></td>';
            echo '<td>' . esc_html( $post_count ) . '</td>';
            echo '<td>' . esc_html( $last_updated ) . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="5">Không tìm thấy site nào trong mạng lưới.</td></tr>';
    }

    echo '</tbody></table>';
    echo '</div>';
}